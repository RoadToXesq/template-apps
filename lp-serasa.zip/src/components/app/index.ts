export { default as MainContent } from './main-content.vue';
