export { default as DefaultPage } from './default-page.vue';
